class BaseProcessor:

    def __init__(self, processor):
        self.processor = processor


    def init_table(self):
        pass
